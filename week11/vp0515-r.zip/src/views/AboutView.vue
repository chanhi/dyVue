<template>
  <div class="about">
    <img alt="Vue logo" src="../assets/logo.png">
  </div>
</template>
